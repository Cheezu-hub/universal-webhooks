
import asyncio
import json
import httpx
from dotenv import load_dotenv
import os

# Load from .env
load_dotenv()

async def test_groq():
    api_key = os.getenv("GROQ_API_KEY")
    model = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
    url = "https://api.groq.com/openai/v1/chat/completions"
    
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    
    payload = {
        "model": model,
        "messages": [
            {"role": "user", "content": "Say hello!"}
        ],
        "max_tokens": 10
    }
    
    print(f"Testing Groq with key: {api_key[:10]}...")
    
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(url, json=payload, headers=headers)
            print(f"Status Code: {response.status_code}")
            if response.status_code == 200:
                print("Success!")
                print(response.json()["choices"][0]["message"]["content"])
            else:
                print(f"Error: {response.text}")
    except Exception as e:
        print(f"Request failed: {e}")

if __name__ == "__main__":
    asyncio.run(test_groq())
